from crypto_utils import encrypt_result, decrypt_expression, generate_shared_key

def test_encrypt_decrypt():
    key = generate_shared_key()
    expression = "2 + pow(2, 3)"
    encrypted = encrypt_result(expression, key)
    decrypted = decrypt_expression(encrypted, key)
    assert decrypted == expression

test_encrypt_decrypt()
print("加解密测试通过")
