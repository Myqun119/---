from flask import Flask, request, render_template, jsonify
#from crypto_utils import decrypt_expression, encrypt_result, generate_shared_key, verify_hmac
from crypto_utils import decrypt_expression, encrypt_result, generate_shared_key, verify_hmac
import math

app = Flask(__name__)


# 简单的 API 密钥验证机制（身份认证）
API_KEY = "secure_token_123"

# 密钥初始化（对称加密）
SHARED_KEY = generate_shared_key()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate', methods=['POST'])
def calculate():
    data = request.get_json()

    if data.get("api_key") != API_KEY:
        return jsonify({"error": "Unauthorized"}), 401

    try:
        encrypted_expr = data['expression']
        received_hmac = data['hmac']


        # ✅ HMAC 验证
        if not verify_hmac(encrypted_expr, received_hmac, SHARED_KEY):
            return jsonify({"error": "消息被篡改"}), 403

        expression = decrypt_expression(encrypted_expr, SHARED_KEY)

        allowed_names = {k: v for k, v in math.__dict__.items() if not k.startswith("__")}
        allowed_names.update({"abs": abs, "round": round})
        result = eval(expression, {"__builtins__": {}}, allowed_names)

        encrypted_result = encrypt_result(str(result), SHARED_KEY)
        return jsonify({"result": encrypted_result})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True)
