from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import base64
import hashlib

# DSA密钥对生成（进阶）
from Crypto.PublicKey import DSA
from Crypto.Random import random
from Crypto.Hash import SHA256

import hmac

# DSA key parameters生成或可固定
# 使用 RFC 3526 group 14 中的素数（2048位）
p = int("""
FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E08
8A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B
302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9
A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE6
49286651ECE65381FFFFFFFFFFFFFFFF
""".replace("\n", "").replace(" ", ""), 16)
 # 可预设2048位素数
g = 2  # 生成元

def dh_generate_keys():
    private_key = random.randint(1, p - 2)
    public_key = pow(g, private_key, p)
    return private_key, public_key

def dh_compute_shared(pub_other, priv_self):
    return pow(pub_other, priv_self, p)

def derive_key(shared_secret):
    return SHA256.new(str(shared_secret).encode()).digest()

#HMAC 验证（改进）

def compute_hmac(data, key):
    return hmac.new(key, data.encode(), digestmod=SHA256).hexdigest()

def verify_hmac(data, received_hmac, key):
    expected_hmac = compute_hmac(data, key)
    return hmac.compare_digest(expected_hmac, received_hmac)
#

# 初始化密钥
def generate_shared_key():
    password = "MyVerySecretPassword"
    return hashlib.sha256(password.encode()).digest()  # 256位密钥

def pad(data):
    # AES块大小为16字节
    return data + (16 - len(data) % 16) * chr(16 - len(data) % 16)

def unpad(data):
    return data[:-ord(data[-1])]

def encrypt_result(text, key):
    text = pad(text)
    iv = get_random_bytes(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    encrypted = cipher.encrypt(text.encode())
    return base64.b64encode(iv + encrypted).decode()

def decrypt_expression(cipher_text, key):
    raw = base64.b64decode(cipher_text)
    iv = raw[:16]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted = cipher.decrypt(raw[16:])
    return unpad(decrypted.decode())

#消息完整性验证（进阶）
import hmac
from Crypto.Hash import SHA256

def compute_hmac(data: str, key: bytes) -> str:
    return hmac.new(key, data.encode(), digestmod=SHA256).hexdigest()

def verify_hmac(data: str, hmac_received: str, key: bytes) -> bool:
    expected_hmac = compute_hmac(data, key)
    return hmac.compare_digest(expected_hmac, hmac_received)
