const API_KEY = "secure_token_123";
const key = CryptoJS.SHA256("MyVerySecretPassword").toString();

// 计算HMAC
function computeHMAC(message, key) {
    // 使用CryptoJS库计算HMAC
    const hash = CryptoJS.HmacSHA256(message, CryptoJS.enc.Hex.parse(key));
    // 将结果转换为十六进制字符串
    return hash.toString(CryptoJS.enc.Hex);
}


function pad(text) {
    const padLen = 16 - (text.length % 16);
    return text + String.fromCharCode(padLen).repeat(padLen);
}

function unpad(text) {
    const padLen = text.charCodeAt(text.length - 1);
    return text.slice(0, -padLen);
}

function encryptAES(text, key) {
    const iv = CryptoJS.lib.WordArray.random(16);
    const padded = pad(text);
    const encrypted = CryptoJS.AES.encrypt(padded, CryptoJS.enc.Hex.parse(key), {
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.NoPadding
    });
    const combined = iv.concat(encrypted.ciphertext);
    return CryptoJS.enc.Base64.stringify(combined);
}

function decryptAES(data, key) {
    const raw = CryptoJS.enc.Base64.parse(data);
    const iv = CryptoJS.lib.WordArray.create(raw.words.slice(0, 4));
    const ciphertext = CryptoJS.lib.WordArray.create(raw.words.slice(4));
    const decrypted = CryptoJS.AES.decrypt({ ciphertext: ciphertext }, CryptoJS.enc.Hex.parse(key), {
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.NoPadding
    });
    return unpad(decrypted.toString(CryptoJS.enc.Utf8));
}

async function sendEncrypted() {
    const expression = document.getElementById("expression").value;
    const encrypted = encryptAES(expression, key);
    const hmac = computeHMAC(encrypted, key);  // 用密钥对密文签名

    const response = await fetch("/calculate", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            expression: encrypted,
            hmac: hmac,
            api_key: API_KEY
        })
    });

    const resultData = await response.json();
    if (resultData.result) {
        const result = decryptAES(resultData.result, key);
        document.getElementById("result").innerText = result;
    } else {
        document.getElementById("result").innerText = resultData.error || "发生错误";
    }
}

